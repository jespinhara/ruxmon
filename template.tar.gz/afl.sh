#!/bin/bash

HOMEDIR=/home/vagrant

sudo apt-get -y update
sudo apt-get -y upgrade
sudo apt-get -y install build-essential
sudo apt-get -y install gdb
sudo apt-get -y install git

cd $HOMEDIR
mkdir tools
mkdir sources

cd $HOMEDIR/tools
wget --quiet http://lcamtuf.coredump.cx/afl/releases/afl-latest.tgz
tar -xzvf afl-latest.tgz
rm afl-latest.tgz
(
  cd afl-*
  make
  sudo make install
)

cd $HOMEDIR/sources
mkdir input
wget --quiet https://gist.githubusercontent.com/superkojiman/595524f6b96c79380568/raw/ee724c73fccf17588c1e4ddd7f3a99882db6b437/classic.c
gcc -fno-stack-protector -z execstack classic.c -o classic
echo A > $HOMEDIR/sources/input/testcase

git clone https://github.com/longld/peda.git ~/peda
echo "source ~/peda/peda.py" >> ~/.gdbinit

echo "do not forget..."
echo "Disable ASLR: # echo 0 > /proc/sys/kernel/randomize_va_space"
echo "# echo core >/proc/sys/kernel/core_pattern"
echo "cd sources;afl-fuzz -n -i input -o output ./classic"
