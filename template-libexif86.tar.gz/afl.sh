#!/bin/bash

HOMEDIR=/home/vagrant

sudo apt-get -y update
sudo apt-get -y upgrade
sudo apt-get -y install build-essential
sudo apt-get -y install gdb
sudo apt-get -y install git
sudo apt-get -y install libpopt0
sudo apt-get -y install libpopt-dev
sudo apt-get -y install pkg-config
sudo apt-get -y install unzip

cd $HOMEDIR
mkdir tools
mkdir sources
mkdir input
mkdir input_crash

cd $HOMEDIR/tools
wget --quiet http://lcamtuf.coredump.cx/afl/releases/afl-latest.tgz
tar xf afl-latest.tgz
rm afl-latest.tgz
(
  cd afl-*
  make
  sudo make install
)

cd $HOMEDIR/sources
wget --quiet https://github.com/jespinhara/ruxmon/raw/master/libexif-0.6.20.tar.gz
tar xf libexif-0.6.20.tar.gz
(
  cd libexif-0.6.20
  CC=afl-gcc ./configure CFLAGS=-fno-stack-protector --disable-shared
  make
  sudo make install
)
wget --quiet https://github.com/jespinhara/ruxmon/raw/master/exif-0.6.20.tar.gz
tar xf exif-0.6.20.tar.gz
(
  cd exif-0.6.20
  CC=afl-gcc ./configure CFLAGS=-fno-stack-protector --disable-shared
  make
  sudo make install
)

cd $HOMEDIR/input
wget --quiet https://github.com/jespinhara/ruxmon/raw/master/corpus.zip
unzip corpus.zip
rm corpus.zip

cd $HOMEDIR/input_crash
wget --quiet https://github.com/jespinhara/ruxmon/raw/master/crash.jpg

git clone https://github.com/longld/peda.git ~/peda
echo "source ~/peda/peda.py" >> ~/.gdbinit

echo "do not forget..."
echo "Disable ASLR: # echo 0 > /proc/sys/kernel/randomize_va_space"
echo "# echo core >/proc/sys/kernel/core_pattern"
